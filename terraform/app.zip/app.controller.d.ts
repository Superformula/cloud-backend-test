export declare class AppController {
    getHealth(): string;
}
