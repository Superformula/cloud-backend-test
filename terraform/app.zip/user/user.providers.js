"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.userProviders = exports.DATABASE_CONNECTION = exports.USER_REPOSITORY = void 0;
const user_entity_1 = require("./user.entity");
exports.USER_REPOSITORY = 'USER_REPOSITORY';
exports.DATABASE_CONNECTION = 'DATABASE_CONNECTION';
exports.userProviders = [
    {
        provide: exports.USER_REPOSITORY,
        useFactory: (connection) => connection.getRepository(user_entity_1.User),
        inject: [exports.DATABASE_CONNECTION]
    }
];
//# sourceMappingURL=user.providers.js.map