import { Connection } from 'typeorm';
import { User } from './user.entity';
export declare const USER_REPOSITORY = "USER_REPOSITORY";
export declare const DATABASE_CONNECTION = "DATABASE_CONNECTION";
export declare const userProviders: {
    provide: string;
    useFactory: (connection: Connection) => import("typeorm").Repository<User>;
    inject: string[];
}[];
