import { Repository } from 'typeorm';
import { User, UserSearchResult } from './user.entity';
export declare type TUserCreate = {
    name: string;
    dob?: Date | null;
    address?: string;
    description?: string;
    imageUrl?: string;
};
export declare type TUserUpdate = {
    name?: string;
    dob?: Date;
    address?: string;
    description?: string;
    imageUrl?: string;
};
export declare class UserService {
    private userRepository;
    constructor(userRepository: Repository<User>);
    create(data: TUserCreate): Promise<User>;
    findById(id: number): Promise<User>;
    findAll(searchText?: string, take?: number, skip?: number): Promise<UserSearchResult>;
    updateById(id: number, data: TUserUpdate): Promise<User>;
    deleteById(id: number): Promise<boolean>;
}
