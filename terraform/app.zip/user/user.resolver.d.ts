import { User, UserSearchResult } from './user.entity';
import { UserService } from './user.service';
export declare class UsersResolver {
    private userService;
    constructor(userService: UserService);
    createUser(name: string, address?: string, description?: string, imageUrl?: string, dob?: string): Promise<User>;
    getUser(id: number): Promise<User>;
    getAllUsers(searchText: string, take?: number, skip?: number): Promise<UserSearchResult>;
    updateUser(id: number, name: string, address?: string, description?: string, imageUrl?: string, dob?: string): Promise<User>;
    deleteUser(id: number): Promise<boolean>;
}
